import java.util.*;

class arrayList4 {
  public static void main(String args[]) {
    ArrayList list1 = new ArrayList();
    list1.add("Keshav memorial institute of technology");
    list1.add("genesis");
    System.out.println(list1);

    System.out.println(list1.contains("institute"));
    System.out.println(list1.contains("genesis"));
  }
}