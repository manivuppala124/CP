import java.util.*;

class arrayList2 {
  public static void main(String args[]) {
    ArrayList <String> list1 = new ArrayList<>();
    list1.add("kmit");
    list1.add(Boolean.TRUE);
    list1.add(21);
    System.out.println(list1);
  }
}