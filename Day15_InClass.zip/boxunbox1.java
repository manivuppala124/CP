public class boxunbox1
{
	public static void main(String [] args) 
	{
		Integer i = 10;
		Integer j = i;

		i++;
		j--;
		System.out.println(i + " " + j);
	}
}