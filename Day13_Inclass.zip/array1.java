class array1 {
  public static void main(String args[]) {
    

   /* int [] arr2, arr3 = {3, 9};   
    //System.out.println(arr2[0]);
    System.out.println(arr3[1]);

    String [] stra1 = {"hello", "world"};
    String [] stra2 =  {"hello", "world"};
    System.out.println(stra1.equals(stra2));
    System.out.println(stra1.toString());
    System.out.println(java.util.Arrays.toString(stra1));*/

    String [] arr4 = new String[2];
    System.out.println(arr4[0]);
    System.out.println(arr4.length);
  }
}
