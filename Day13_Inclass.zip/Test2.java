class Test2{
	public static void main(String args[]){
		int []b, a;
		a = new int[3];
		
		System.out.println(a[0]+" "+a[1]+" "+a[2]);
	}
}