class string2 {
	public static void main(String[] args) 	{
		String ch = "";
		for(int i = 0; i< 26; i++){
			ch = ch + (i+1);
		
		System.out.println(ch);  
    /*String s1 = "hello";
    String s2 = "Hello";
    String s3 = "HellO".intern();
    String s4 = new String("Hello");
    String s5 = new String("Hello").intern();
    if (s1 == s2){
      System.out.println("s1 and s2 are same");  
    }
	if (s1 == s3){
      System.out.println("s1 and s3 are same" );  
    }
    if (s1 == s4){
      System.out.println("s1 and s4 are same" );  
    }
    if (s2 == s5){
      System.out.println("s1 and s5 are same" );  
    }*/
  }
}